/*
  Reservation class, stores the person and room number in the Hotel
*/

public class Reservation{
    //instance variables
    private String name;
    private int roomNumber;

    //constructors, must supply the name, and optionally a room
    public Reservation(String person){
    	

    }
    public Reservation(String person, int room){
    

    }

    //mutators, set the room number or name
    public void setRoom(int newroom){
    	
    }

    public void setName(String newname){
    	
    }

    //accessors, return the room number or name
    public int getRoom(){
    	
    }

    public String getName(){
    	
    }
}